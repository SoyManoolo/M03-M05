public class Div {
    public Div() {
    }

    public float div2(float a, float b) {
        return a / b;
    }

    public float div3(float a, float b, float c) {
        float x = a / b;
        return x / c;
    }
}