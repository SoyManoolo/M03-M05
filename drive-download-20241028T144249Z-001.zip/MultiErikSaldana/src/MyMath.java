public class MyMath {
    public float multi(float n1, float n2){
        return n1*n2;
    }
}