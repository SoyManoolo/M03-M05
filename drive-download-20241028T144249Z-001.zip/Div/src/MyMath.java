public class MyMath {

    private static float div(float a, float b) {
        return a/b;
    }

    public float div(float a, float b, float c){
        return div(a,b) / c;
    }
}
