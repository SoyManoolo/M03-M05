public class Main {

    public static void Achraf(){
        for (int i=0;i<5;i++){
            System.out.print("Achraf__");
        }
    }
    public static void user2othman(){
        for (int i=0;i<5;i++){
            System.out.print("user 2 es othman");
        }
    }

    public static void user3(){
        for (int i=0;i<5;i++){
            System.out.print("Hola, SoyManooloooooooooooooo y tengo 18 años");
        }
    }

    public static void user4(){
        for (int i=0;i<5;i++){
            System.out.print("NEGRIU");
        }
    }



    public static void main(String[] args) {

        Achraf();
        System.out.println();
        // escribe tu methodo aquiiiiiiiiiiii!!!
        // ggg oo
        //dss



    }
}

