public class comida {
    private Peix[] peixos;
}
