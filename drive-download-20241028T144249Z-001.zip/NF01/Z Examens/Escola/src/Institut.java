public class Institut {
    private String nom;

    public Institut(String nom) {
        this.nom = nom;
    }

    private Aula[] aula;

    public String getNom() {
        return nom;
    }
}
