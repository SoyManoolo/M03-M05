
public class Main {
    public static void main(String[] args) {
        Gos gos = new Gos();
        Gat gat = new Gat();

        gos.lladrar();
        gat.miolar();
    }
}
