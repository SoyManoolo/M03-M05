import static org.junit.jupiter.api.Assertions.*;

class JuegoTest {

    @org.junit.jupiter.api.Test
    void novaPartida() {
    }

    @org.junit.jupiter.api.Test
    void jugar() {
    }

    @org.junit.jupiter.api.Test
    void jugadaGuanyadora() {
    }
}