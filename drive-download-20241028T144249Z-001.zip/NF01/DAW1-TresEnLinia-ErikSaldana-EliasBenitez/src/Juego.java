public class Juego {

    public void novaPartida() {

    }

    public void jugar() {

    }

    public void jugadaGuanyadora() {

    }
}
