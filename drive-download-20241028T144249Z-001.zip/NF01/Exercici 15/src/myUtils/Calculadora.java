package myUtils;

public class Calculadora {
    int id;
    public float suma(float p1, float p2) {
        return p1+p2;
    }
    public float resta(float p1, float p2) {
        return p1-p2;
    }
    public float multiplicacion(float p1, float p2) {
        return p1*p2;
    }
    public float division(float p1, float p2) {
        return p1/p2;
    }
}
