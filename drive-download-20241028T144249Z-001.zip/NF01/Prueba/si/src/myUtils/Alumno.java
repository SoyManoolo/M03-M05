package myUtils;

public class Alumno {
    float nota1;
    float nota2;
    float nota3;
}
