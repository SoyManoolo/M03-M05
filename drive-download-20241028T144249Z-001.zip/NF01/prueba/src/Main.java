import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        for (int i = 10; i > 0; i--) {
            System.out.println(i);
        }
    }
}
