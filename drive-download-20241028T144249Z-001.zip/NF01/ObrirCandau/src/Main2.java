import java.util.Locale;
import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        int clau = sc.nextInt();
        int actual = sc.nextInt();
        int suma = sc.nextInt();
        int mult = sc.nextInt();

        while (true) {

        }
    }
}