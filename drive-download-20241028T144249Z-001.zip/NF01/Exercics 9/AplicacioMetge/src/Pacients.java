import java.util.Date;

public class Pacients {
    private String nom;
    private String cognom;
    private String DNI;
    private Date data_naixement;
    private String genere;
    private int alcada;
    private int pes;
    private String allergies;
    private String medicaments_actuals;
    private String malalties_croniques;
    private String operacionsuirurgiques;
}
