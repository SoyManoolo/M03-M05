public class Fruita {
    private float quantitat_venuda;
    private float preu_fruita_venuda;
    private float benefici;
}
