public class Pokemon {
    private String nom;
    private String tipus;
    private int generacio;
    private boolean capturat;
    private int identificador;
}
