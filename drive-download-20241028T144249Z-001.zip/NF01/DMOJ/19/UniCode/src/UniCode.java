public class UniCode {

    private char chA;
    private char chB;
    private char chC;
    private char chD;
    private char chE;
    private char chF;

    public UniCode(int a, int b, int c, int d, int e, int f) {
        this.chA = (char) a;
        this.chB = (char) b;
        this.chC = (char) c;
        this.chD = (char) d;
        this.chE = (char) e;
        this.chF = (char) f;
    }

    public char getChA() {
        return chA;
    }

    public char getChB() {
        return chB;
    }

    public char getChC() {
        return chC;
    }

    public char getChD() {
        return chD;
    }

    public char getChE() {
        return chE;
    }

    public char getChF() {
        return chF;
    }

}
