public class si {
    public static void main(String[] args) {
        int a;
        float b = 91.976f;
        a = (int)b;

        System.out.println(a);
    }
}
