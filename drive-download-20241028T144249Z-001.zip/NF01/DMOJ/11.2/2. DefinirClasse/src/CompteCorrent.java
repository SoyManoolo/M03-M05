public class CompteCorrent {
    public float saldo;
    public String nomPropietari;
    public  boolean bloquejada;

}
