public class Box {
    public float width;
    public float height;
    public float length;
    public Box innerBox;
}
