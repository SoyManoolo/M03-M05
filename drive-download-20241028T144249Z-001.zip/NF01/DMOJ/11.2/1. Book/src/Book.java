public class Book {
    public String title;
    public Integer yearOfPublishing;
    public boolean isAvailable;
}
