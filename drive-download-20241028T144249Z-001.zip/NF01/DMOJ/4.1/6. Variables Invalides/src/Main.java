import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        scanner.useLocale(Locale.ENGLISH);

       Integer a = 512343;
       Integer b = 3431231;

        System.out.println(a + b);
    }
}