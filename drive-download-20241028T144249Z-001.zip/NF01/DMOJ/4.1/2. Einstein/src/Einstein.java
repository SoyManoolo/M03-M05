public class Einstein {
    public static void main (String[] args) {
        System.out.println("Life is like riding a bicycle. To keep your balance you must keep moving");
    }
}