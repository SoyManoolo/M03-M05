public class Main {
    public static void main(String[] args) {
        float x = 1.01f;
        System.out.println(x);
        System.out.println(2*x);
        System.out.println(3*x);
        System.out.println(4*x);
        System.out.println(5*x);
    }
}
