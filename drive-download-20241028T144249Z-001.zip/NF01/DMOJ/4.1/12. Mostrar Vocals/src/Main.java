public class Main {
    public static void main(String[] args) {
        System.out.println('a');
        System.out.println('e');
        System.out.println('i');
        System.out.println('o');
        System.out.println('u');
    }
}
