import java.util.Scanner;
public class Main{
    public static void main(String[] args) {
        Alumne a = new Alumne();
        System.out.println(a.presentarse());
    }
}