public class Num {
    private int a;
    private int b;
    private int c;
    private int d;

    public Num(float a, float b, float c, float d) {
        this.a = (int) a;
        this.b = (int) b;
        this.c = (int) c;
        this.d = (int) d;
    }

    public int getA() {
        return a;
    }

    public int getB() {
        return b;
    }

    public int getC() {
        return c;
    }

    public int getD() {
        return d;
    }
}
