import java.util.Scanner;

public class Hola {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String nom = scanner.nextLine();
        System.out.println("Hola " + nom + "!");
    }
}
