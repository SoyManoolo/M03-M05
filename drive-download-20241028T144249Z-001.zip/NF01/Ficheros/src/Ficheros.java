import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Ficheros {

    //metodo para crear un fichero dentro de un directorio y escribir en él
    public void createFile(String folderPath, String fileName, ArrayList<String> content) throws IOException {
        //Crear directorio
        File directorio = new File(folderPath); //crea un objeto File con el directorio
        if (!directorio.exists()) directorio.mkdirs(); //si no existe el directorio, lo crea

        //Crear fichero y escribir en él
        File fichero = new File(directorio, fileName); //crea el fichero dentro del directorio
        FileWriter escribir = new FileWriter(fichero); //crea un objeto FileWriter para escribir en el fichero

        for (String c: content) { //recorre el contenido de la ArrayList y lo escribe en el fichero
            escribir.write(c + "\n");
        }
        escribir.close(); //cierra el objeto FileWriter

    }

    //metodo para leer un fichero
    public ArrayList<String> readFile(String relPath) throws IOException{
        //Ha de llegir el fitxer (path relatiu, l'arrel serà la ruta del projecte).
        File file = new File(relPath);
        Scanner sc = new Scanner(file);
        ArrayList<String> content = new ArrayList<>();

        while (sc.hasNextLine()) {
            content.add(sc.nextLine());
        }
        sc.close();
        return content;
    }

    //metodo para borrar un fichero
    public void borrarFicheroDirectorio(String fileName) {
        File borrar = new File(fileName);
        if(borrar.delete()) {
            System.out.println("Fichero o directorio borrado: " + borrar.getName());
        } else {
            System.out.println("El fichero o directorio no se ha podido borrar.");
        }
    }

}
