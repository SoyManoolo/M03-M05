import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws IOException {
        String folderPath = "dir1/dir2";
        String folder1 = "dir1";
        String fileName = "file";


        Ficheros f = new Ficheros();


        ArrayList<String> content = new ArrayList<>(Arrays.asList("Linia 1", "Linia 2", "Linia 3"));
        content.add("Linia 4 with add");

        //f.createFile(folderPath, fileName, content);



      //  f.borrarDirectorioFichero(folderPath, fileName);


        f.borrarFicheroDirectorio(folderPath + "/" + fileName);
        f.borrarFicheroDirectorio(folderPath);
        f.borrarFicheroDirectorio(folder1);


    }
}