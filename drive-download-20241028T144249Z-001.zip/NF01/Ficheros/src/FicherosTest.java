import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.*;



class FicherosTest {

    @org.junit.jupiter.api.Test
    void createDirectory() throws IOException {
        Ficheros fichero = new Ficheros();
        String folderPath = "dir1/dir2";
        String fileName = "file";
        File f = new File(folderPath, fileName);

        ArrayList<String> content = new ArrayList<>(Arrays.asList("Linia 1", "Linia 2", "Linia 3"));
        content.add("Linia 4 with add");

        fichero.borrarFicheroDirectorio(folderPath + "/" + fileName);
        fichero.borrarFicheroDirectorio(folderPath);
        fichero.borrarFicheroDirectorio("dir1");

        fichero.createFile(folderPath, fileName, content);

        Assertions.assertTrue(f.exists());
    }

    @org.junit.jupiter.api.Test
    void readFile() throws IOException {
        Ficheros fichero = new Ficheros();
        String folderPath = "dir1/dir2";
        String fileName = "file";
        File file = new File(folderPath, fileName);

        ArrayList<String> content = new ArrayList<>(Arrays.asList("Linia 1", "Linia 2", "Linia 3"));
        content.add("Linia 4 with add");

        fichero.createFile(folderPath, fileName, content);

        File f = new File(folderPath, fileName);
        ArrayList<String> llegit = fichero.readFile(f.getPath());

        Assertions.assertTrue(content.equals(llegit));

        Assertions.assertEquals(content, llegit);
    }
}