public class carta {
    int puntsMana;
    int puntsVida;
    int puntsAtac;
    String nomCarta;
    boolean Cartadaurada;
    short tipusCarta;
    String dibuix;
}
