import java.util.Date;

public class Pacients {
    public String nom;
    public String cognom;
    public String DNI;
    public Date data_naixement;
    public String genere;
    public int alcada;
    public int pes;
    public String allergies;
    public String medicaments_actuals;
    public String malalties_croniques;
    public String operacionsuirurgiques;
}
