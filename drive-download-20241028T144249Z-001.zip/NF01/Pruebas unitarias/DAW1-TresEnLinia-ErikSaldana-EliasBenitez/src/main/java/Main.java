public class Main {
    public void novaPartida() {

    }

    public void carregarPartida() {

    }

    public void configuracio() {

    }

    public void sortir() {

    }


    public static void main(String[] args) {

    }
}