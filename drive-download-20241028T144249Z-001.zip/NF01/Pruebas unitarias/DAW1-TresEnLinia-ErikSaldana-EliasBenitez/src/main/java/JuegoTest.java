import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class JuegoTest {

    @org.junit.jupiter.api.Test
    void novaPartida() {

    }

    @org.junit.jupiter.api.Test
    void jugar() {
    }

    @org.junit.jupiter.api.Test
    void jugadaGuanyadora() {
    }
}