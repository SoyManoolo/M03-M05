public class Alumne extends Persona{
    private float nota;

    public Alumne(float nota, String nom) {
        this.nota = nota;
        this.nom = nom;
    }

    public float getNota() {
        return nota;
    }

    public void setNota(float nota) {
        this.nota = nota;
    }
}
