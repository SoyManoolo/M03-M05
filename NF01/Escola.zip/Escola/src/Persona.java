public class Persona {
    protected String nom;

    public Persona(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }
}
